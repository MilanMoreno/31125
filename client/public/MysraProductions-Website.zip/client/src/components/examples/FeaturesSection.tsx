import FeaturesSection from '../FeaturesSection';

export default function FeaturesSectionExample() {
  return <FeaturesSection />;
}
