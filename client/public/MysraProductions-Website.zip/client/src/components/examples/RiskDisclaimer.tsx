import RiskDisclaimer from '../RiskDisclaimer';

export default function RiskDisclaimerExample() {
  return <RiskDisclaimer />;
}
