import PricingSection from '../PricingSection';

export default function PricingSectionExample() {
  return <PricingSection />;
}
